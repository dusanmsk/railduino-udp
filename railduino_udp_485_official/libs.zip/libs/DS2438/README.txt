DS2438 Arduino OneWire Library

To install, download and rename the arduino-onewire-DS2438 folder to DS2438 and copy the DS2438 folder structure to your Arduino libraries folder.

Requires Arduino 1.0 or greater and OneWire Arduino library (see http://playground.arduino.cc/Learning/OneWire).

For additional information see http://projects.bechter.com

